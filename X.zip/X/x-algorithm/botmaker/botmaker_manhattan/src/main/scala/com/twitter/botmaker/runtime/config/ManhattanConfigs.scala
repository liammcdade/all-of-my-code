package com.twitter.botmaker.runtime.config

trait ManhattanConfigs extends ManhattanEndpointConfigs with ManhattanClientConfigs
